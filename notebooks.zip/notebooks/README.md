# Notebooks

Ubicación para las libretas o scripts que sean utilizados para la experimentación del proyecto.

Usualmente se suele anexar otra carpeta a la raíz del proyecto denominada **app** o similar que contenga el resultado final a ser utilizado en una instancia de producción.
